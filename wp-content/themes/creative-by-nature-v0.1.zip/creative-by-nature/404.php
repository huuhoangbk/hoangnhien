<?php get_header(); ?>
<div class="box">
	<img src="<?=_p()?>/images/empty.gif" class="green-leaves" alt="" />
	<div class="box-t">&nbsp;</div>
	<div class="box-c">
		<div class="box-cnt two-columns">
			<div class="cl">&nbsp;</div>
			<div class="side-left">
				<div class="posts">
					<h2 class="center">Error 404 - Not Found</h2>
				</div>
			</div>
			<div class="side-right">
				<?php get_sidebar(); ?>
			</div>
			<div class="cl">&nbsp;</div>
		</div>
	</div>
	<div class="box-b">&nbsp;</div>
</div>
<?php get_footer(); ?>