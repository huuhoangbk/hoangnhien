<div id="sidebar">
	<h2>Latest Headlines</h2>
	<ul>
		<?=_list_latest_posts(10, 0);?>
	</ul>
</div>